﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ReportApp
{
    public class Custom
    {
        public void GetReports()
        {
            return;
        }
    }
}